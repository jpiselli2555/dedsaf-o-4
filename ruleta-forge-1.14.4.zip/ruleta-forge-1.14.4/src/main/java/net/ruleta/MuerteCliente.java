package net.ruleta;

import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Animación en pantalla al morir: velo rojo que sube y "HAS MUERTO" con rebote. */
@Mod.EventBusSubscriber(modid = Ruleta.ID, value = Dist.CLIENT)
public class MuerteCliente {
    private static long inicio = -1;

    @SubscribeEvent
    public static void alAbrir(GuiOpenEvent e) {
        inicio = (e.getGui() instanceof DeathScreen) ? System.currentTimeMillis() : -1;
    }

    @SubscribeEvent
    public static void alDibujar(GuiScreenEvent.DrawScreenEvent.Post e) {
        if (inicio < 0 || !(e.getGui() instanceof DeathScreen)) return;
        Minecraft mc = Minecraft.getInstance();
        int w = e.getGui().width, h = e.getGui().height;
        float t = (System.currentTimeMillis() - inicio) / 1000.0F;

        // Velo rojo: sube en 1,2 s hasta ~60 % de opacidad.
        float a = Math.min(t / 1.2F, 1.0F) * 0.6F;
        int alfa = (int) (a * 255) << 24;
        AbstractGui.fill(0, 0, w, h, alfa | 0x400000);

        // Texto con "pop": aparece a los 0,4 s, crece con rebote y se asienta.
        float u = (t - 0.4F) / 0.6F;
        if (u <= 0) return;
        u = Math.min(u, 1.0F);
        float escala = 4.0F * (1.0F + 0.35F * (1.0F - u) * (float) Math.cos(u * 9.0F));
        String txt = "HAS MUERTO";
        int ancho = mc.fontRenderer.getStringWidth(txt);

        GlStateManager.pushMatrix();
        GlStateManager.translatef(w / 2.0F, h / 3.0F, 0);
        GlStateManager.scalef(escala, escala, 1.0F);
        mc.fontRenderer.drawStringWithShadow(txt, -ancho / 2.0F, -4.0F, 0xFFFF3030);
        GlStateManager.popMatrix();
    }
}
