package net.ruleta;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.play.server.SPlaySoundEffectPacket;
import net.minecraft.network.play.server.STitlePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;

/** Momento Reviil: temporizador y gas tóxico por debajo de la capa 250. */
@Mod.EventBusSubscriber(modid = Ruleta.ID)
public class Reviil {
    private static final int CAPA = 250;
    private static final float DANO = 2.0F;

    private static boolean activo = false;
    private static boolean fase_dano = false;
    private static long finEn = 0;

    @SubscribeEvent
    public static void alIniciar(FMLServerStartingEvent e) {
        e.getCommandDispatcher().register(
            Commands.literal("reviil")
                .requires(s -> s.hasPermissionLevel(2))
                .then(Commands.literal("stop").executes(c -> detener(c.getSource())))
                .executes(c -> lanzar(c.getSource(), 120))
                .then(Commands.argument("segundos", IntegerArgumentType.integer(5, 3600))
                    .executes(c -> lanzar(c.getSource(), IntegerArgumentType.getInteger(c, "segundos"))))
        );
    }

    private static int lanzar(CommandSource src, int segundos) {
        MinecraftServer s = src.getServer();
        activo = true;
        fase_dano = false;
        finEn = s.getTickCounter() + segundos * 20L;

        ITextComponent titulo = new StringTextComponent("MOMENTO REVIIL")
            .applyTextStyle(TextFormatting.RED);
        ITextComponent mensaje = new StringTextComponent(
            "MOMENTO REVIIL: Reviil ha liberado un gas tóxico invisible en todas las dimensiones! "
            + "Antes que termine el temporizador TODOS deben estar POR ENCIMA de la Capa " + CAPA
            + ", o recibirán daño hasta morir.").applyTextStyle(TextFormatting.RED);

        for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) {
            p.sendMessage(mensaje);
            p.connection.sendPacket(new STitlePacket(STitlePacket.Type.TITLE, titulo));
            sonido(p, Sonidos.ESCENA_REVIIL);
            sonido(p, Sonidos.MUSICA_REVIIL);
        }
        return 1;
    }

    private static int detener(CommandSource src) {
        activo = false;
        fase_dano = false;
        src.sendFeedback(new StringTextComponent("Momento Reviil detenido."), true);
        return 1;
    }

    private static void sonido(ServerPlayerEntity p, net.minecraft.util.SoundEvent snd) {
        p.connection.sendPacket(new SPlaySoundEffectPacket(snd, SoundCategory.MASTER,
            p.posX, p.posY, p.posZ, 1.0F, 1.0F));
    }

    @SubscribeEvent
    public static void alTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !activo) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null || s.getTickCounter() % 20 != 0) return;

        long restantes = (finEn - s.getTickCounter()) / 20;
        if (!fase_dano && restantes <= 0) {
            fase_dano = true;
            s.getPlayerList().sendMessage(new StringTextComponent(
                "¡Se acabó el tiempo! El gas tóxico hace efecto por debajo de la Capa " + CAPA + ".")
                .applyTextStyle(TextFormatting.DARK_RED));
        }

        for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) {
            if (!fase_dano) {
                String t = String.format("Reviil: %02d:%02d", restantes / 60, restantes % 60);
                p.connection.sendPacket(new STitlePacket(STitlePacket.Type.ACTIONBAR,
                    new StringTextComponent(t).applyTextStyle(TextFormatting.RED)));
            } else if (p.posY < CAPA && !p.isCreative() && !p.isSpectator()) {
                p.attackEntityFrom(DamageSource.MAGIC, DANO);
            }
        }
    }
}
