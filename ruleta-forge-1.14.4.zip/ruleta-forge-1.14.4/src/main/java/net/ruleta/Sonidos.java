package net.ruleta;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Ruleta.ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class Sonidos {
    public static final SoundEvent ESCENA_REVIIL = crear("escenas.reviil");
    public static final SoundEvent MUSICA_REVIIL = crear("reviil_musica");

    private static SoundEvent crear(String nombre) {
        ResourceLocation id = new ResourceLocation(Ruleta.ID, nombre);
        return new SoundEvent(id).setRegistryName(id);
    }

    @SubscribeEvent
    public static void registrar(RegistryEvent.Register<SoundEvent> e) {
        e.getRegistry().registerAll(ESCENA_REVIIL, MUSICA_REVIIL);
    }
}
