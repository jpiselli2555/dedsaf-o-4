package net.ruleta;

import net.minecraftforge.fml.common.Mod;

@Mod(Ruleta.ID)
public class Ruleta {
    public static final String ID = "ruleta";
}
