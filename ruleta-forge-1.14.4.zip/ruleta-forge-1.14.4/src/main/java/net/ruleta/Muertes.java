package net.ruleta;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Avisos en el chat: tótems que "popean" y muertes con su causa. */
@Mod.EventBusSubscriber(modid = Ruleta.ID)
public class Muertes {

    /** Si el golpe lo mataría y lleva un tótem en alguna mano, el tótem se va a consumir. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void alRecibirDano(LivingDamageEvent e) {
        LivingEntity ent = e.getEntityLiving();
        if (!(ent instanceof ServerPlayerEntity) || e.isCanceled()) return;
        ServerPlayerEntity p = (ServerPlayerEntity) ent;
        DamageSource fuente = e.getSource();

        boolean letal = p.getHealth() - e.getAmount() <= 0.0F;
        boolean tieneTotem = p.getHeldItemMainhand().getItem() == Items.TOTEM_OF_UNDYING
                          || p.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING;
        if (!letal || !tieneTotem || fuente.canHarmInCreative()) return;

        ITextComponent msg = new StringTextComponent("✦ ")
            .applyTextStyle(TextFormatting.GOLD)
            .appendSibling(p.getDisplayName())
            .appendSibling(new StringTextComponent(" consumió un Tótem de la Inmortalidad (")
                .applyTextStyle(TextFormatting.YELLOW))
            .appendSibling(fuente.getDeathMessage(p))
            .appendSibling(new StringTextComponent(")").applyTextStyle(TextFormatting.YELLOW));
        p.getServer().getPlayerList().sendMessage(msg);
    }

    /** Muerte de un jugador: mensaje con la causa. */
    @SubscribeEvent
    public static void alMorir(LivingDeathEvent e) {
        if (!(e.getEntityLiving() instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity p = (ServerPlayerEntity) e.getEntityLiving();
        ITextComponent msg = new StringTextComponent("☠ ")
            .applyTextStyle(TextFormatting.DARK_RED)
            .appendSibling(e.getSource().getDeathMessage(p).deepCopy()
                .applyTextStyle(TextFormatting.RED));
        p.getServer().getPlayerList().sendMessage(msg);
    }
}
